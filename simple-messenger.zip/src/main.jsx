import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import SimpleMessenger from './SimpleMessenger'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <SimpleMessenger />
  </React.StrictMode>,
)
